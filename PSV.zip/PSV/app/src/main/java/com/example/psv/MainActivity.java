package com.example.psv;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.bluetooth.*;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import com.skyfishjy.library.RippleBackground;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    BluetoothAdapter bluetoothAdapter;
    Location location;
    static int REQUEST_ENABLE_BT;
    ListView listView;
    LocationListener locationListener;
    LocationManager locationManager;
    RippleBackground findDevice;
    Switch aSwitch;


    RecyclerView recyclerView;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager layoutManager;

    private  List<ModelView> modelViewList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        aSwitch = (Switch) findViewById(R.id.btn_switch);
        findDevice = (RippleBackground) findViewById(R.id.content) ;

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();


        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    findDevice.startRippleAnimation();
                    bluetoothAdapter.startDiscovery();
                } else{
                    unregisterReceiver(broadcastReceiver);
                    findDevice.stopRippleAnimation();
                }
            }
        });

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Dispositivo não suporta Bluetooth.", Toast.LENGTH_SHORT).show();
        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        }

        // Register for broadcasts when a device is discovered.
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(broadcastReceiver, filter);

        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // add data to the list
        AddData();

        // specify an adapter (see also next example)
        mAdapter = new MyAdapter(this.getApplicationContext(), modelViewList);
        recyclerView.setAdapter(mAdapter);

    }

    private  void  AddData(){
        modelViewList.add(new ModelView("Stianeth João", "1"));
        modelViewList.add(new ModelView("Amadeu Jeremias", "3"));
        modelViewList.add(new ModelView("Alfredo Martins", "5"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        unregisterReceiver(broadcastReceiver);
    }

    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);


                String deviceName = device.getName();
                String deviceAddress = device.getAddress();

                modelViewList.add(new ModelView(deviceName, deviceAddress));
            }
        }
    };


}